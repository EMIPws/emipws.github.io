The folders EMIP3_1_2_J, EMIP3_1_2_Py etc. have to be copied into the SMI Experiment Center directory (usually "C:\Program Files(x86)\SMI\Experiment Suite 360\Experiment Center 2\Experiments").

EMIP3_1_2_J, EMIP3_1_2_Py, and EMIP3_1_2_S show the program "Rectangle" first, then "Vehicle". In EMIP3_2_1_J, EMIP3_2_1_Py, and EMIP3_2_1_S the order is reversed.

The experiment was created with a 1920×1080 screen. Depending on the resolution used for recording, the slides might have to be reformatted.

Experiment Center has the option to set the same prefix for all recordings using "Global Settings" - "Naming". This label can be used to identify all recordings from the same institution. It can directly name the institution, but doesn't have to.

Sources:
-Rectangle
Based on a Python program by Michael Hansen
http://eyecode.synesthesiam.com/stories/programs.html#rectangle
-Vehicle
Shortened and slightly adapted from Java teaching material provided by Falko Ripsas a CS high school teacher from Berlin

